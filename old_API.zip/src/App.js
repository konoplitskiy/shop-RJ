import React from 'react';
import axios from "axios";
import Card from './components/Card';
import Header from './components/Header/Header';
import Draver from './components/Draver/Draver';
import './App.scss';





function App() {
    const [cartOpnened, setCartOpened] = React.useState(false);
    const [cartItems,setCartItems] = React.useState([]);
    const [items,setItems] = React.useState([]);
    const [searchValue,setSearchValue] = React.useState('');


    // fetch variant

  // React.useEffect(()=> {
  //     fetch('https://60e2b6939103bd0017b474c0.mockapi.io/items')
  //         .then(res=>{
  //             return res.json();
  //         })
  //         .then(json=> {
  //             setItems(json)
  //         })
  // },[])


    //axios variant
    React.useEffect(()=> {
        axios.get('https://60e2b6939103bd0017b474c0.mockapi.io/items').then(res=>{
            setItems(res.data)
        })
        axios.get('https://60e2b6939103bd0017b474c0.mockapi.io/cart').then(res=>{
            setCartItems(res.data)
        })
    },[])


    // const onAddToCart = (obj) => {
    //     setCartItems([...cartItems,obj])
    //     console.log(cartItems)
    // }

    const onAddToCart = (obj) => {
        axios.post('https://60e2b6939103bd0017b474c0.mockapi.io/cart', obj);
        setCartItems(prev =>[...prev,obj]);
    }


    const onRemoveItem = (id)=> {
        console.log(id);
        axios.delete(`https://60e2b6939103bd0017b474c0.mockapi.io/cart/${id}`);
        setCartItems(prev =>prev.filter(item => item.id !== id));
    }


    const onFavorite = (obj) => {
        axios.post('https://60e2b6939103bd0017b474c0.mockapi.io/cart', obj);
        setCartItems(prev =>[...prev,obj]);
    }


    const  onChangeSearchInput = (event)=> {
        setSearchValue(event.target.value);
    }

  return (
    <div className="wrapper clear">
        {cartOpnened && <Draver items={cartItems}  onRemove={onRemoveItem} onClose = {()=> setCartOpened(false)}/> }
     <Header onClickCart = {()=> setCartOpened(true)}/>
        <div className="content p-40 ">
            <div className="d-flex align-center justify-between mb-40">
                <h1 className="mb-40">{searchValue ? `Поиск по запросу ${searchValue}`: "Все красовки"}</h1>
                <div className="search-block d-flex">
                    <img src="/img/search.svg" alt=""/>
                    { searchValue && <img onClick={()=> setSearchValue('')} className="removeBtn clear cu-p" src="/img/delon.svg" alt="Clear"/>}
                    <input type="text" placeholder="Поиск..." value={searchValue}  onChange={onChangeSearchInput}/>
                </div>
            </div>
            <div className="card-list d-flex flex-wrap">
                {
                   items
                       .filter((item)=> item.name.toLowerCase().includes(searchValue.toLowerCase()))
                       .map((item,index) => {
                       return <Card
                           key={`${index}${item.price}`}
                           title={item.name}
                           price={item.price}
                           imgUrl ={item.imgUrl}
                           onFavorite ={()=> console.log('Добавили в закладки')}
                           onPlus={(obj)=>onAddToCart(obj)}
                       />
                   })
                }
            </div>
        </div> 
    </div>
  );
}

export default App;

// #5 video  01:15:00
